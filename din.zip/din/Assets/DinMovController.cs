﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class DinMovController : MonoBehaviour, IDragHandler, IPointerUpHandler, IPointerDownHandler
{
    [SerializeField]
    private RuntimeAnimatorController[] controllers;

    [SerializeField]
    private Button btn;

    private int movOpt = 1;

    private Dictionary<string, int> action = new Dictionary<string, int>() 
    {
        {"inicio", 0}, {"camina", 1}, {"corre", 2}, {"más info", 3}
    };

    private Dictionary<string, int> dinIndex = new Dictionary<string, int>() 
    {
        {"Stegosaurus", 0}, {"Raptor", 1}
    };

    private string curAction;
    private GameObject Din;
    private Animator animator;
    public RectTransform gamePad;
    public float speed = 5.0f;
    Vector3 move;
    bool walking;
    int  curIndex;
    float delta = 1;


    private void getCurIndex()
    {
        curIndex = dinIndex[Din.name];
        if(curIndex == 1)
            delta = -1.0f;
    }

    public void OnDrag(PointerEventData eventData)
    {

        transform.position = eventData.position;
        transform.localPosition = Vector2.ClampMagnitude(eventData.position - (Vector2)gamePad.position, gamePad.rect.width * 0.5f);

        move = new Vector3(transform.localPosition.x * delta, 0f, transform.localPosition.y * delta).normalized;

        if(!walking)
        {
            walking = true;
            animator.runtimeAnimatorController = controllers[curIndex*3 + movOpt] as RuntimeAnimatorController;
        }

    }

    public void OnPointerDown(PointerEventData eventData)
    {
        Din = GameObject.FindGameObjectWithTag("din");
        animator = Din.GetComponent<Animator>();
        getCurIndex();
        StartCoroutine(moveDin());
    }

    public void OnPointerUp(PointerEventData eventData)
    {
        transform.localPosition = Vector3.zero;
        move = Vector3.zero;
        StopCoroutine(moveDin());
        walking = false;
        animator.runtimeAnimatorController = controllers[curIndex*3 + 0] as RuntimeAnimatorController;
    }

    IEnumerator moveDin() {  
        while(true)
        {
            Din.transform.Translate(move * speed * delta * Time.deltaTime, Space.World);

            if(move != Vector3.zero)
            {
                Din.transform.rotation = Quaternion.Slerp(Din.transform.rotation, Quaternion.LookRotation(move), Time.deltaTime * 5.0f);
            }
            
            yield return null;
        }
    }

    public void RunDin() 
    {
        var txt = btn.GetComponentInChildren<Text>();

        if(btn.image.color == Color.black)
        {
            btn.image.color = Color.white;
            txt.color = Color.black;
            movOpt = 1;
            speed = 5.0f;
        }
        else
        {
            btn.image.color = Color.black;
            txt.color = Color.white;
            movOpt = 2;
            speed = 10.0f;
        }
    }

    void GetDin()
    {  
        Din = GameObject.FindGameObjectWithTag("din");
        animator = Din.GetComponent<Animator>();
        getCurIndex();
    }

    void Start()
    {
        var txt = btn.GetComponentInChildren<Text>();
        btn.image.color = Color.white;
        txt.color = Color.black;
    }

    void Update()
    {
    }
}
