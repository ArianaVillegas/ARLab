﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using UnityEngine.Networking;

public class ARController : MonoBehaviour
{
    [SerializeField]
    private GameObject AR;

    [SerializeField]
    private InputField inputAction;

    [SerializeField]
    public AudioClip[] description;

    [SerializeField]
    private GameObject canvasMenu;

    [SerializeField]
    private GameObject canvasInput;

    [SerializeField]
    private RuntimeAnimatorController[] controllers;

    private Dictionary<string, int> action = new Dictionary<string, int>() 
    {
        {"inicio", 0}, {"camina", 1}, {"corre", 2}, {"más info", 3}
    };

    private string curAction;
    private int curIdx;
    private Animator animator;
    private AudioSource audioSource;
    private GameObject StartBtn;
    private GameObject ChooseBtn;
    private GameObject OptDin;
    private GameObject Game;
    private GameObject[] DinOpts; 

    void Start()
    {
        curIdx = 0;

        audioSource = GetComponent<AudioSource>();
        StartBtn = GameObject.FindGameObjectWithTag("StartBtn");
        ChooseBtn = GameObject.FindGameObjectWithTag("ChooseBtn");
        OptDin = GameObject.FindGameObjectWithTag("OptDin");
        Game = GameObject.FindGameObjectWithTag("Game");

        DinOpts = new GameObject[OptDin.transform.childCount];
        for(int i = 0; i < DinOpts.Length; i++)
        {
            DinOpts[i] = OptDin.transform.GetChild(i).gameObject;
        }

        foreach(GameObject go in DinOpts)
        {
            go.SetActive(false);
        }
        
        canvasMenu.SetActive(true);
        canvasInput.SetActive(false);
        StartBtn.SetActive(true);
        ChooseBtn.SetActive(false);
        Game.SetActive(true);
    }

    void ChangeAction(string curAction)
    {
        if(curAction != "más info")
        {
            animator.runtimeAnimatorController = controllers[curIdx*3 + action[curAction]] as RuntimeAnimatorController;
        }
        else 
        {
            System.Console.WriteLine(curIdx);
            animator.runtimeAnimatorController = controllers[curIdx*3 + 0] as RuntimeAnimatorController;
            audioSource.PlayOneShot(description[curIdx]);
        }
        AR.SetActive(true);
    }

    void ClearConfigBtn(){
        var objects = GameObject.FindGameObjectsWithTag("OptBtn");
        foreach (GameObject obj in objects) 
        {
            var btn = obj.GetComponent<Button>();
            btn.image.color = Color.white;
            var txt = btn.GetComponentInChildren<Text>();
            txt.color = Color.black;
        }
        audioSource.Stop();
    }

    public void SearchAction() 
    {
        var btn = GameObject.Find(EventSystem.current.currentSelectedGameObject.name).GetComponent<Button>();
        var txt = btn.GetComponentInChildren<Text>();

        if(btn.image.color == Color.black)
        {
            ClearConfigBtn();
            ChangeAction("inicio");
        }
        else
        {
            ClearConfigBtn();
            btn.image.color = Color.black;
            txt.color = Color.white;
            ChangeAction(txt.text.ToLower());
        }
    }

    public void ChooseDin()
    {
        canvasInput.SetActive(false);
        StartBtn.SetActive(false);
        ChooseBtn.SetActive(true);
        DinOpts[curIdx].gameObject.SetActive(true);
    }

    public void LeftArrow()
    {
        DinOpts[curIdx].gameObject.SetActive(false);
        curIdx = (DinOpts.Length + curIdx-1) % DinOpts.Length;
        DinOpts[curIdx].gameObject.SetActive(true);
    }

    public void RightArrow()
    {
        DinOpts[curIdx].gameObject.SetActive(false);
        curIdx = (curIdx+1) % DinOpts.Length;
        DinOpts[curIdx].gameObject.SetActive(true);
    }

    public void HideMenuPanel()
    {
        canvasMenu.SetActive(false);
        canvasInput.SetActive(true);
        Game.SetActive(true);
        DinOpts[curIdx].gameObject.tag = "din";
        animator = DinOpts[curIdx].gameObject.GetComponent<Animator>();
    }


    // Update is called once per frame
    void Update()
    {
    }
}
